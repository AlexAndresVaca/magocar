
<?php $__env->startSection('nombre_pagina'); ?>
Lineas
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cuerpo'); ?>
<div class="espacio_lineas">
            <div class="lineas">
                <span>Moquetas</span>
                <img src="sources/img/logo_ico.svg" alt="imagen_linea">
            </div>
            <div class="lineas">
                <span>Alarmas</span>
                <img src="" alt="imagen_linea">
            </div>
            <div class="lineas">
                <span>Antenas</span>
                <img src="" alt="imagen_linea">
            </div>
            <div class="lineas">
                <span>Audio</span>
                <img src="" alt="imagen_linea">
            </div>
            <div class="lineas">
                <span>Electronica</span>
                <img src="" alt="imagen_linea">
            </div>
            <div class="lineas">
                <span>Luces</span>
                <img src="" alt="imagen_linea">
            </div>
            <div class="lineas">
                <span>Miquelados</span>
                <img src="" alt="imagen_linea">
            </div>
            <div class="lineas">
                <span>Piezas y repuestos</span>
                <img src="" alt="imagen_linea">
            </div>
            <div class="lineas">
                <span>4 x 4</span>
                <img src="" alt="imagen_linea">
            </div>
            <div class="lineas">
                <span>Emblémas</span>
                <img src="" alt="imagen_linea">
            </div>
            <div class="lineas">
                <span>Halógenos</span>
                <img src="" alt="imagen_linea">
            </div>
            <div class="lineas">
                <span>Herramientas</span>
                <img src="sources/img/logo_ico.svg" alt="imagen_linea">
            </div>
            <div class="lineas">
                <span>Láminas y Polarizados</span>
                <img src="" alt="imagen_linea">
            </div>
            <div class="lineas">
                <span>Limpieza</span>
                <img src="" alt="imagen_linea">
            </div>
            <div class="lineas">
                <span>Plumas</span>
                <img src="" alt="imagen_linea">
            </div>
            <div class="lineas">
                <span>Tuning</span>
                <img src="" alt="imagen_linea">
            </div>
            <div class="lineas">
                <span>Accesorios</span>
                <img src="" alt="imagen_linea">
            </div>
            <a href="producto.html">
                <div class="lineas">
                    <span>Demo</span>
                    <img src="" alt="imagen_linea">
                </div>
            </a>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('header_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\proyecto_magocar_1\resources\views/public/index.blade.php ENDPATH**/ ?>