var container = document.getElementById('container');
setTimeout(function() {
 container.classList.add('cerrar')
}, 3000)    
